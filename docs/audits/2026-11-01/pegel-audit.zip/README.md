# Pegel-Audit – Übergabepaket

Stand: **1. November 2026**. Geprüfter Repository-Commit: `018c2d33f980bf1b746352fded27267985c21d0d`.

- **AUDIT.html**: vollständiger, lokal lesbarer Bericht mit Inhaltsverzeichnis und Architekturdiagrammen.
- **AUDIT.md**: bearbeitbare Markdown-Fassung desselben Berichts.
- **SECURITY.html / SECURITY.md**: separater Sicherheitsbericht.
- **evidence/**: Testergebnisse, Auditmeldungen, Messwerte, Screenshots und Rechenmodelle.
- **tests/**: zusätzliche lokale Reproduktionen und vorbereitete Emulatorfälle.
- **tools/package.json / package-lock.json**: getrennte Werkzeugumgebung; keine Änderungen an den Anwendungsabhängigkeiten.
- **SHA256SUMS.txt**: Prüfsummen der enthaltenen Dateien.

Zum Lesen das ZIP entpacken und `AUDIT.html` öffnen. Die HTML-Dateien benötigen weder einen Server noch eine Internetverbindung; nur aufgerufene Quellenlinks führen ins Internet. Die Druckansicht ist für Querformat ausgelegt. Dateien aus dem Anwendungsrepository sind auf den geprüften GitHub-Commit verlinkt.

## Tatsächlich ausgeführt

87 vorhandene Testdateien / 1.048 bestandene Tests, Lint, TypeScript-/Produktionsbuild; saubere Installation und Buildvergleich mit 390 identischen Dateien; getrennte npm-Audits; begrenzter historischer Secretformatscan; Chromium-UI/Accessibilitytests; echter Zwei-Tab-Test; isolierte Cleanup-Reproduktion mit Originalfunktion/Fake-DB; Initialzustände aller 20 Spiele; drei synthetische lokale Performance-Läufe; Kosten-/Erlösberechnungen.

**Nicht ausgeführt:** Firebase-Emulatortests, Produktions-/Staginglasttests, native iOS-/Android-Builds, Hardware-/Safari-Tests. Der offizielle Emulator-Download wurde vom Netzwerkproxy mit HTTP 403 blockiert. Produktive Rules, Abrechnungen, Betriebsverträge und Storekonten wurden nicht geprüft.

Ein erfolgreicher Reproduktionstest kann einen Fehler **bestätigen**. Die zusätzlichen Tests sind kein Beleg für eine sichere Releaseversion. Insbesondere erwartet `rules-audit.mjs` teilweise bewusst die unsicheren Rechte des Ist-Stands. Vor Nutzung als Freigabeprüfung sind Erwartungen und Auth-Fixtures dem korrigierten Protokoll anzupassen.

## Reproduktion der Zusatzprüfungen

Die Scripts wurden für folgende lokale Verzeichnisse erstellt:

```text
/workspace/Scientific-Drinking-Game  geprüfte Anwendung
/workspace/audit-pegel              dieses Paket
```

Sie enthalten absolute Pfade. Bei einem anderen Arbeitsverzeichnis diese **lokalen Dateipfade** anpassen; Testziele dürfen nicht auf eine Produktionsdatenbank umgestellt werden. Ein vorhandenes lokales Repository auf den genannten Commit auschecken, ohne ungesicherte eigene Änderungen zu überschreiben.

Die Werkzeugumgebung ist unabhängig vom App-Lockfile. Zur Neuinstallation werden Node 24, npm, Java 21 für den Emulator und ein kompatibles Chromium benötigt. Die Browser-Scripts verwenden `/usr/bin/chromium`; gegebenenfalls nur diesen lokalen Programmpfad anpassen.

```bash
cd /workspace/audit-pegel
npm ci --ignore-scripts --prefix tools
ln -s tools/node_modules node_modules
```

Den Symlink-Befehl nur ausführen, wenn `node_modules` noch nicht existiert. Die vollständigen Pakete und Caches sind nicht im ZIP enthalten. Die Installation und der Emulator-Download benötigen erlaubten Netzwerkzugriff; die eigentlichen Testziele sind lokal.

Vor Browserprüfungen in einem eigenen Terminal den vorhandenen Produktionsbuild der App lokal bereitstellen:

```bash
cd /workspace/Scientific-Drinking-Game
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

Zusatzprüfungen aus dem Auditverzeichnis einzeln starten:

```bash
node tests/two-tabs.mjs
node tests/browser-audit.mjs
node tests/performance.mjs
node tests/local-reproductions.cjs
python tests/model.py
../Scientific-Drinking-Game/node_modules/.bin/vitest run --config vitest.config.mjs
```

Die Browser-Scripts verwenden synthetische lokale Profile. Online-Lobbyfunktionen werden dabei nicht ausgelöst; externe HTTP-Anfragen werden blockiert. Die Cleanup-Reproduktion verwendet eine Fake-DB und importiert keine produktive Admin-Verbindung.

Vorbereitete Rules-Suite, bisher **nicht ausgeführt**:

```bash
FIREBASE_EMULATORS_PATH=/workspace/audit-pegel/emulators \
  ./tools/node_modules/.bin/firebase emulators:exec \
  --only database --project demo-pegel-audit --config firebase.json \
  'node tests/rules-audit.mjs'
```

Das Testscript bindet den Datenbankzugriff ausdrücklich an `127.0.0.1:9000` und ein Demo-Projekt. Die Tests enthalten absichtliche Löschungen ausschließlich im lokalen Emulator. Der Lasttestplan im Hauptbericht ist ein separater Vorschlag und wurde nicht gestartet.

## Änderungen und Grenzen

Anwendungscode, Rules und App-Lockfiles blieben unverändert; der Git-Arbeitsbaum war bei der abschließenden Kontrolle sauber. Nichts wurde veröffentlicht oder deployt. Keine Produktionsdatenbankzugriffe und keine kostenpflichtigen Cloud-Aktionen. Bericht und zusätzliche Werkzeuge liegen außerhalb des Repositorys.

Der Bericht trennt Codebelege, tatsächlich ausgeführte Reproduktionen, offene Risiken und Empfehlungen. Rechtliche, steuerliche und medizinische Fragen sind Vorprüfungen anhand der genannten Tatsachen und offiziellen Quellen; keine individuelle Freigabe.

Öffentliche E-Mail-Adressen in zwei Installationslogs wurden redigiert; Exitstatus, Paketmeldungen und Testergebnisse wurden dadurch nicht verändert.
