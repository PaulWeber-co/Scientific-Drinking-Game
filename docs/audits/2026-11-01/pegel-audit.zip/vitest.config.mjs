import { defineConfig } from '/workspace/Scientific-Drinking-Game/node_modules/vitest/dist/config.js';
export default defineConfig({
  root:'/workspace/Scientific-Drinking-Game',
  define:{__GAME_BUILD__:JSON.stringify('audit')},
  test:{environment:'jsdom',include:['/workspace/audit-pegel/tests/game-sizes.test.ts']}
});
