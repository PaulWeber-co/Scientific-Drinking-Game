const fs = require('node:fs');
const path = require('node:path');
const { marked } = require('marked');
const root = '/workspace/audit-pegel';
const commit = '018c2d33f980bf1b746352fded27267985c21d0d';
const files = fs.readFileSync(path.join(root, 'evidence/inventory.txt'), 'utf8').trim().split('\n');
const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const slug = s => s.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

let source = fs.readFileSync(path.join(root, 'AUDIT.md'), 'utf8');
// Link source references to the precise reviewed revision. Never resolve code fragments as paths.
let fenced = false;
source = source.split('\n').map(line => {
  if (line.startsWith('```')) { fenced = !fenced; return line; }
  if (fenced) return line;
  return line.replace(/`([^`]+)`/g, (whole, value) => {
    const match = value.match(/^([A-Za-z0-9_./-]+\.[A-Za-z0-9]+)(?::(\d+)(?:[–-](\d+))?)?$/);
    if (!match) return whole;
    const [, name, start, end] = match;
    if (name === 'firebase.json' && line.includes('tests/rules-audit.mjs')) return '[firebase.json](firebase.json)';
    const hits = files.includes(name) ? [name] : files.filter(f => f.endsWith('/' + name));
    if (hits.length === 1) {
      const file = hits[0];
      const label = file + (start ? ':' + start + (end ? '–' + end : '') : '');
      const anchor = start ? '#L' + start + (end ? '-L' + end : '') : '';
      return '[' + label + '](https://github.com/PaulWeber-co/Scientific-Drinking-Game/blob/' + commit + '/' + file + anchor + ')';
    }
    const local = [name, 'evidence/' + name, 'tests/' + name].filter(f => fs.existsSync(path.join(root, f)) && fs.statSync(path.join(root, f)).isFile());
    if (local.length && !start) return '[' + name + '](' + local[0] + ')';
    return whole;
  });
}).join('\n');
fs.writeFileSync(path.join(root, 'AUDIT.md'), source);

function extract(start, end) {
  const a = source.indexOf(start), b = end ? source.indexOf(end, a) : source.length;
  if (a < 0 || b < 0) throw new Error('Missing report section: ' + start);
  return source.slice(a, b).trim();
}
const risks = extract('## C.', '### Konkrete Reproduktionen');
const relevantIds = new Set(['S01','S02','S03','S04','M01','M02','M03','M04','M05','M06','L01','L03','D01','O01']);
const securityRows = risks.split('\n').filter(l => l.startsWith('| ID ') || l.startsWith('|---') || relevantIds.has(l.split('|')[1]?.trim())).join('\n');
const security = `# Pegel – separater Sicherheitsbericht\n\n**Stand:** 1. November 2026 · **Commit:** \`${commit}\`.\n\n**Ergebnis: Öffentlicher Online-Launch vor Behebung von S01 nicht freigegeben.** Die Repository-Rules erlauben ohne Authentifizierung weitreichende Zugriffe auf bekannte Räume. Die produktiv deployten Rules wurden nicht ausgelesen; ein produktiver Angriff oder Datenabfluss wurde nicht festgestellt.\n\nDies ist der gesonderte Security-Teil des [vollständigen Audits](AUDIT.md). Anwendungscode, Rules und Lockfiles blieben unverändert. Keine Produktionsdatenbankzugriffe, Cloud-Lasttests, Deployments oder Veröffentlichung.\n\n${extract('## Leseschlüssel', '## A.')}\n\n## Priorisierte Sicherheits- und Integritätsbefunde\n\nAufwand in Entwicklertagen (ET), ohne externe Freigaben; überlappende Änderungen nicht doppelt addieren.\n\n${securityRows}\n\n${extract('### Konkrete Reproduktionen', '## D.').replace(/^### Konkrete Reproduktionen/, '## Konkrete Reproduktionen')}\n\n${extract('## D.', '## E.').replace(/^## D\. Security-Bericht und tatsächlich ausgeführte Prüfungen/, '## Sicherheitskontrollen und tatsächlich ausgeführte Prüfungen')}\n\n## Freigabekriterien\n\n1. Anonyme Auth und echte Mitglieds-/Hostrechte sind serverseitig durchgesetzt; fremde Räume und Playerpfade werden abgewiesen. Alle legitimen Pfade funktionieren.\n2. Create, Runde, actionId, State/Ack und Hostwechsel sind unter konkurrierenden Clients konsistent; doppelte Zustellung verändert den Zustand höchstens einmal.\n3. Private Hände liegen in privaten Sichten; Zone und Avatare sind minimiert und nur im freigegebenen Umfang erreichbar.\n4. Zwei-Tab-Regression, Reconnect/Failover, manipulierte Eingaben und Cleanup-Rennen werden mit echten Integrationen getestet.\n5. Geprüfte Rules-Version, Cleanup-Deployment, Kostenalarme und Abhängigkeits-Triage sind dokumentiert.\n\nDie vorbereiteten Emulatorfälle in [tests/rules-audit.mjs](tests/rules-audit.mjs) wurden **nicht ausgeführt**: Der offizielle Emulator-Download wurde mit HTTP 403 blockiert. Manche Fälle erwarten bewusst den unsicheren Ist-Zustand, um ihn zu reproduzieren; sie sind keine Freigabe-Suite für eine gehärtete Version. Nach Korrektur sind diese Erwartungen in serverseitige Ablehnungen umzuwandeln und authentifizierte positive Fälle zu ergänzen.\n\nReproduktionsbefehle, alle Evidenzdateien, Architektur, Store- und Rechtsfragen stehen im [Hauptbericht](AUDIT.md).\n`;
fs.writeFileSync(path.join(root, 'SECURITY.md'), security);

function diagram(future) {
  const nodes = future ? [
    [20,45,260,75,'Bestehende React-App','Web / Capacitor'],
    [350,45,260,75,'Anonyme Auth','Verifizierte UID'],
    [680,45,260,75,'Lokale Daten','Körperdaten und Fotos'],
    [20,230,260,90,'Wenige Cloud Functions','Create / Join / Aktionen','Identität, Schema und Limits'],
    [350,230,260,90,'Atomare Zustandsführung','Runde, Revision, actionId','Host-Epoche / Idempotenz'],
    [680,230,260,90,'Enge Rules','Mitgliedschaft und eigene','Presence / private Leserechte'],
    [20,430,260,75,'Begrenzter Cleanup','Generation + Ablauf prüfen'],
    [350,430,260,75,'Öffentlicher Raumzustand','Nur für Mitglieder'],
    [680,430,260,75,'Private Spielersichten','Je authentifizierter UID']
  ] : [
    [20,45,260,75,'Lokale Daten','Profil / Trinklog / Fotos'],
    [350,45,260,75,'Statische Auslieferung','GitHub Actions → Pages'],
    [680,45,260,75,'Weitere Spieler','Bekannter Raumcode'],
    [20,230,260,90,'Browser / PWA','Behauptete Geräte-ID','Manipulierbarer Client'],
    [350,230,260,90,'RTDB Rules','Keine Authentifizierung','Breite Freigabe am Raum'],
    [680,230,260,90,'Realtime Database','lobbies / CODE','State, Inbox, Spieler, Avatare'],
    [350,430,260,75,'Cleanup-Function','Stündlich; Deployment offen'],
    [680,430,260,75,'Host-Browser','Reducer und Queue','Schreibt ganzen JSON-State']
  ];
  const edges = future ? [
    ['M280 82 H350','Identität',315,72],
    ['M150 120 V230','Aktionen',205,181],
    ['M280 275 H350','',0,0],
    ['M480 320 V430','State + Ack',541,379],
    ['M610 290 H640 V397 H810 V430','private Daten',737,390],
    ['M280 467 H350','',0,0],
    ['M810 320 V430','Leserechte',864,375],
    ['M150 120 V160 H810 V120','lokal',695,153]
  ] : [
    ['M350 82 H320 V200 H150 V230','Build',298,166],
    ['M150 230 V120','lokal',192,177],
    ['M280 275 H350','Code',315,264],
    ['M610 275 H680','',0,0],
    ['M810 230 V120','Snapshot',867,178],
    ['M810 320 V430','Inbox',849,379],
    ['M940 466 H960 V290 H940','State',937,386],
    ['M610 467 H645 V315 H680','Löschen',608,374]
  ];
  const boxes = nodes.map((n,i) => `<g><rect x="${n[0]}" y="${n[1]}" width="${n[2]}" height="${n[3]}" rx="10" fill="${!future && i===4?'#fff0ee':'#f4f7fa'}" stroke="${!future && i===4?'#b13f32':'#a5b6c6'}"/><text x="${n[0]+n[2]/2}" y="${n[1]+27}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="16" fill="#172c42">${n.slice(4).map((t,j)=>`<tspan x="${n[0]+n[2]/2}" dy="${j?21:0}" font-size="${j?14:16}" font-weight="${j?400:650}">${escape(t)}</tspan>`).join('')}</text></g>`).join('');
  const lines = edges.map(([d,l,x,y])=>`<path d="${d}" fill="none" stroke="#536f88" stroke-width="2" marker-end="url(#arrow${future?1:0})"/>${l?`<text x="${x}" y="${y}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="13" fill="#41596e">${escape(l)}</text>`:''}`).join('');
  return `<figure class="architecture"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 980 545" role="img" aria-label="${future?'Empfohlene Architektur mit Auth, Serveraktionen und privaten Sichten':'Ist-Architektur mit unzureichender Vertrauensgrenze an den RTDB Rules'}"><defs><marker id="arrow${future?1:0}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8z" fill="#536f88"/></marker></defs>${lines}${boxes}</svg><figcaption>${future?'Sollbild: gezielte Ergänzung der bestehenden App.':'Istbild: zentrale Komponenten und Datenwege.'} Vereinfachte Übersicht; vollständige Verbindungen im aufklappbaren Mermaid-Quelltext.</figcaption></figure>`;
}

const css = `
:root{color-scheme:light;--ink:#172c42;--muted:#4b6072;--line:#d8e1e9;--accent:#1d5b87;--paper:#fff}
body{overflow-wrap:anywhere}.report-links{display:flex;flex-wrap:wrap;gap:10px 18px}.report-links a{white-space:nowrap;margin-right:0!important}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:24px}body{margin:0;color:var(--ink);font:16px/1.65 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#eef2f5}a{color:var(--accent);text-decoration-thickness:1px;text-underline-offset:3px;overflow-wrap:anywhere}a:hover{color:#102f47}a:focus-visible,summary:focus-visible{outline:3px solid #b0540b;outline-offset:4px}.skip{position:absolute;left:16px;top:-100px}.skip:focus{top:12px;background:white;padding:12px;z-index:5}.layout{display:grid;grid-template-columns:250px minmax(0,1fr);max-width:1530px;margin:auto}aside{position:sticky;top:0;height:100vh;overflow:auto;padding:35px 20px 35px 25px;border-right:1px solid var(--line)}.brand{font-weight:800;font-size:26px;letter-spacing:-1px}.eyebrow{font-size:11px;letter-spacing:2px;text-transform:uppercase;color:var(--muted)}nav ol{list-style:none;padding:0;margin:26px 0}nav li{margin:12px 0}nav a{display:block;text-decoration:none;font-size:13px;line-height:1.5}aside p{font-size:12px;color:var(--muted)}main{min-width:0;background:var(--paper);padding:42px 48px 80px}h1{font-size:38px;line-height:1.18;letter-spacing:-1.1px;margin:0 0 26px;max-width:900px}h2{font-size:27px;line-height:1.25;letter-spacing:-.5px;margin:60px 0 22px;padding-top:25px;border-top:2px solid var(--line)}h3{font-size:20px;line-height:1.35;margin:32px 0 15px}p{margin:15px 0}li{margin:7px 0}code{font:13px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace;background:#f0f3f6;padding:2px 5px;border-radius:4px;overflow-wrap:anywhere}pre{background:#f1f5f8;padding:20px;overflow:auto;border:1px solid var(--line);border-radius:8px}pre code{background:none;padding:0}.table-wrap{overflow:auto;margin:22px 0;border:1px solid var(--line);border-radius:8px}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.5}th{text-align:left;background:#eaf0f5;font-weight:700;vertical-align:top}td,th{padding:12px 13px;border-bottom:1px solid var(--line);min-width:90px;overflow-wrap:anywhere}td code{font-size:12px}td:first-child{font-weight:550}tbody tr:nth-child(even){background:#fafbfd}tr:last-child td{border-bottom:0}.table-wrap.wide table{min-width:1100px}.statusbar{display:flex;gap:12px;flex-wrap:wrap;margin:0 0 26px}.statusbar span{padding:7px 11px;border-radius:6px;font-size:12px;font-weight:650;background:#edf3f8;border:1px solid #d1dce6}.statusbar .hold{background:#fff0ee;color:#8c281e;border-color:#e8b6ae}.architecture{margin:25px 0;padding:8px;border:1px solid var(--line);border-radius:10px}.architecture svg{width:100%;height:auto;display:block}figcaption{font-size:12px;color:var(--muted);padding:8px 15px 12px}details{margin:12px 0}summary{cursor:pointer;font-size:13px;color:var(--muted)}.report-links{padding:15px 0;border-bottom:1px solid var(--line);margin-bottom:30px;font-size:13px}.report-links a{margin-right:18px}footer{margin-top:50px;padding-top:20px;border-top:1px solid var(--line);font-size:12px;color:var(--muted)}
@media(max-width:1000px){.layout{grid-template-columns:200px minmax(0,1fr)}main{padding:30px 25px}aside{padding:28px 16px}h1{font-size:31px}}
@media(max-width:720px){.layout{display:block}aside{position:static;height:auto;padding:20px;border-right:0;border-bottom:1px solid var(--line)}nav ol{columns:2;margin:12px 0}nav li{break-inside:avoid;margin:0 0 10px}.brand{font-size:23px}aside p{display:none}main{padding:25px 18px}h1{font-size:29px}h2{font-size:24px;margin-top:42px}.statusbar{gap:7px}.architecture{overflow:auto}.architecture svg{min-width:650px}}
@media print{@page{size:A4 landscape;margin:14mm}body{background:white;font-size:10pt;line-height:1.48}.layout{display:block;max-width:none}aside,.skip,.statusbar,.report-links,details{display:none}main{padding:0}h1{font-size:26pt}h2{font-size:19pt;break-before:page;margin-top:0}h3{font-size:13pt;break-after:avoid}p,li{orphans:3;widows:3}table{font-size:8pt}.table-wrap,.table-wrap.wide{overflow:visible;border:0}.table-wrap.wide table{min-width:0}td,th{padding:6px;min-width:0}thead{display:table-header-group}tr,figure{break-inside:avoid}pre{white-space:pre-wrap}a{color:inherit;text-decoration:none}.architecture svg{max-height:120mm}footer{font-size:8pt}}
`;

for (const [name, text] of [['AUDIT',source],['SECURITY',security]]) {
  let html = marked.parse(text, {gfm:true});
  const toc = [];
  html = html.replace(/<h2>(.*?)<\/h2>/g, (m,title) => {const plain=title.replace(/<[^>]*>/g,'');const id=slug(plain);toc.push({plain,id});return `<h2 id="${id}">${title}</h2>`;});
  let diagramIndex = 0;
  html = html.replace(/<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/g,(_,code)=>diagram(diagramIndex++>0)+`<details><summary>Vollständigen Diagramm-Quelltext anzeigen</summary><pre><code>${code}</code></pre></details>`);
  html = html.replace(/<table>([\s\S]*?)<\/table>/g,(_,inner)=>`<div class="table-wrap${(inner.match(/<th(?:\s|>)/g)||[]).length>=7?' wide':''}"><table>${inner}</table></div>`);
  html = html.replace(/href="AUDIT.md"/g, 'href="AUDIT.html"').replace(/href="SECURITY.md"/g, 'href="SECURITY.html"');
  const title=name==='AUDIT'?'Pegel · Vollständiges Release-Audit':'Pegel · Sicherheitsbericht';
  const page=`<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'"><title>${title}</title><style>${css}</style></head><body><a class="skip" href="#report">Zum Bericht</a><div class="layout"><aside><div class="eyebrow">Release-Audit · 01.11.2026</div><div class="brand">Pegel</div><nav aria-label="Inhaltsverzeichnis"><ol>${toc.map(t=>`<li><a href="#${t.id}">${escape(t.plain)}</a></li>`).join('')}</ol></nav><p>Commit<br><code>${commit.slice(0,12)}</code></p><p>Lokales Dokument. Keine externen Ressourcen oder Analyse-Skripte. Quellenlinks öffnen die jeweiligen Originalquellen.</p></aside><main id="report"><div class="statusbar"><span class="hold">Release: NO-GO</span><span>1.048 Bestandstests bestanden</span><span>Rules-Emulator: nicht ausgeführt</span></div><div class="report-links"><a href="AUDIT.html">Vollständiges Audit</a><a href="SECURITY.html">Sicherheitsbericht</a><a href="${name}.md">Markdown</a><a href="pegel-audit.zip">Nachweispaket</a></div>${html}<footer>Audit des angegebenen Repository-Stands. Nachgewiesene Eigenschaften, offene Risiken und Empfehlungen sind getrennt gekennzeichnet. Anwendungscode unverändert.</footer></main></div></body></html>`;
  fs.writeFileSync(path.join(root,name+'.html'),page);
}
console.log(JSON.stringify({rendered:['AUDIT.html','SECURITY.html'],findings:source.split('\n').filter(l=>/^\| [A-Z]\d{2} \|/.test(l)).length,sourceBytes:Buffer.byteLength(source)},null,2));
