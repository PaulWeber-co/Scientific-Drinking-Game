from pathlib import Path
import json,csv,math
out=Path('/workspace/audit-pegel/evidence')
group=6;duration=90*60;sessions=4;actions=duration/5;remote=actions*(group-1)/group;heartbeats=group*duration/20;hostbeats=duration/40
writes=heartbeats+hostbeats+actions+2*remote
per_session=(actions*8192+heartbeats*200+hostbeats*150+remote*350+group*20000+30000)*1.3
rows=[]
for mau in [100,1000,10000,100000,1000000]:
 D=mau*sessions*per_session/1e9
 rows.append(dict(mau=mau,online_user_sessions=mau*sessions,room_sessions=mau*sessions/group,peak_ccu_1pct=max(1,mau*.01),viral_ccu_10pct=mau*.1,monthly_logical_writes=mau*sessions/group*writes,download_GB=D,rtdb_USD_uniform=max(0,D-30*.36),rtdb_USD_4_active_days=max(0,D-4*.36)))
with (out/'cost-model.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
concurrency=[]
for n in [2,10,100,1000,10000]:
 rooms=math.ceil(n/group);concurrency.append(dict(clients=n,rooms=rooms,writes_per_second=n/20+rooms/40+rooms/5*(1+2*(group-1)/group),game_state_MB_written_per_minute=rooms/5*8192*60/1e6))
rev=[]
for mau in [1000,10000,100000]:
 buyers=mau*.02;gross=buyers*4.99;base=gross/1.19;cost=next(x['rtdb_USD_4_active_days'] for x in rows if x['mau']==mau)*.9;reserve={1000:10,10000:30,100000:150}[mau]
 rev.append(dict(mau=mau,new_buyers=buyers,gross_EUR=gross,ex_vat_EUR=base,after_fee_15pct_EUR=base*.85,after_fee_25pct_EUR=base*.75,modeled_rtdb_EUR=cost,other_assumed_reserve_EUR=reserve,contribution_15pct_EUR=base*.85-cost-reserve,contribution_25pct_EUR=base*.75-cost-reserve))
result={'assumptions':{'group':group,'minutes':90,'sessions_per_MAU':sessions,'state_bytes':8192,'actions_per_room':actions,'heartbeat_payload_bytes':200,'wire_factor':1.3,'per_player_session_MB':per_session/1e6,'writes_per_room_session':writes,'FX_EUR_per_USD_model_only':.9},'scenarios':rows,'concurrency':concurrency,'monetization':rev}
(out/'cost-model.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
