import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
const browser = await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const checks = [];
try {
  for (const name of ['AUDIT','SECURITY']) {
    const page = await browser.newPage({viewport:{width:1440,height:1100}});
    const requests = [], errors = [];
    page.on('request', r => {if(/^https?:/.test(r.url())) requests.push(r.url());});
    page.on('pageerror', e => errors.push(e.message));
    await page.setContent(await readFile(`/workspace/audit-pegel/${name}.html`,'utf8'));
    checks.push({name,width:1440,...await page.evaluate(()=>({
      headings:document.querySelectorAll('h2').length,
      tables:document.querySelectorAll('table').length,
      diagrams:document.querySelectorAll('svg').length,
      overflow:document.documentElement.scrollWidth>innerWidth,
      missingAnchors:[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(a.hash.slice(1))).map(a=>a.hash),
      textLength:document.querySelector('main').innerText.length
    })),requests,errors});
    if(name==='AUDIT') await page.screenshot({path:'/workspace/audit-pegel/evidence/report-desktop.png'});
    await page.setViewportSize({width:390,height:844});
    checks.push({name,width:390,...await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,
      overflowingElements:[...document.querySelectorAll('main > *')].filter(e=>e.getBoundingClientRect().right>innerWidth).map(e=>({tag:e.tagName,class:e.className,width:e.getBoundingClientRect().width,text:e.textContent.slice(0,80)}))
    }))});
    if(name==='AUDIT') await page.screenshot({path:'/workspace/audit-pegel/evidence/report-mobile.png'});
    await page.close();
  }
} finally {await browser.close();}
await writeFile('/workspace/audit-pegel/evidence/report-check.json',JSON.stringify(checks,null,2));
console.log(JSON.stringify(checks,null,2));
if(checks.some(c=>c.overflow||c.errors?.length||c.requests?.length||c.missingAnchors?.length)) process.exitCode=1;
