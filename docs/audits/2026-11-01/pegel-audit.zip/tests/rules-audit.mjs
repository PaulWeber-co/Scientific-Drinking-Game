import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import { ref, set, get, update, remove } from 'firebase/database';

// Deliberately hardcoded local emulator: this file cannot target production.
const env = await initializeTestEnvironment({
  projectId: 'demo-pegel-audit',
  database: { host: '127.0.0.1', port: 9000,
    rules: await readFile('/workspace/Scientific-Drinking-Game/database.rules.json', 'utf8') },
});
const db = env.unauthenticatedContext().database();
const out = [];
const fixture = (code, host = 'host') => ({
  meta: { code, host, createdAt: Date.now(), expiresAt: Date.now() + 3600000, status: 'playing', gameId: 'test' },
  players: { [host]: { id: host, name: 'Synthetic Host', joinedAt: Date.now(), lastSeen: Date.now() } },
  game: { id: 'test', startedAt: 1, state: '{"counter":0}' },
});
async function check(name, kind, work) {
  try { await work(); out.push({ name, kind, reproduced: true }); }
  catch (e) { out.push({ name, kind, reproduced: false, error: e.message }); }
}
try {
  await env.clearDatabase();
  await check('root enumeration denied', 'positive control', () => assertFails(get(ref(db, 'lobbies'))));
  await check('unauthenticated room creation', 'abuse condition', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1'), fixture('AUDIT1'))));
  await check('unauthenticated room read', 'vulnerability', () => assertSucceeds(get(ref(db, 'lobbies/AUDIT1'))));
  await check('foreign player modification', 'vulnerability', () => assertSucceeds(update(ref(db, 'lobbies/AUDIT1/players/host'), { name: 'Changed by outsider' })));
  await check('host takeover without membership', 'vulnerability', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1/meta/host'), 'outsider')));
  await check('arbitrary valid JSON game state', 'vulnerability', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1/game/state'), '{"counter":999}')));
  await check('invalid JSON game state', 'vulnerability', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1/game/state'), 'not-json')));
  await check('action sender impersonation', 'vulnerability', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1/inbox/msg1'), { by: 'host', at: -1, action: '{"type":"anything"}' })));
  await check('unknown field rejected', 'positive control', () => assertFails(set(ref(db, 'lobbies/AUDIT1/players/host/weight'), 75)));
  await check('oversized name rejected', 'positive control', () => assertFails(set(ref(db, 'lobbies/AUDIT1/players/host/name'), 'x'.repeat(25))));
  await check('oversized game string rejected', 'positive control', () => assertFails(set(ref(db, 'lobbies/AUDIT1/game/state'), 'x'.repeat(200001))));
  await check('avatar child deny cannot revoke parent grant', 'vulnerability', () => assertSucceeds(set(ref(db, 'lobbies/AUDIT1/avatars/host'), 'data:image/jpeg;base64,not-a-jpeg')));
  await check('foreign player deletion', 'vulnerability', () => assertSucceeds(remove(ref(db, 'lobbies/AUDIT1/players/host'))));
  await check('past expiry accepted and remains readable', 'vulnerability', async () => {
    await set(ref(db, 'lobbies/AUDIT2'), fixture('AUDIT2'));
    await set(ref(db, 'lobbies/AUDIT2/meta/expiresAt'), 1);
    await assertSucceeds(get(ref(db, 'lobbies/AUDIT2')));
    await assertFails(set(ref(db, 'lobbies/AUDIT2/meta/host'), 'outsider'));
  });
  await check('expired foreign room can be deleted', 'vulnerability', () => assertSucceeds(remove(ref(db, 'lobbies/AUDIT2'))));
  await check('foreign room deletion', 'vulnerability', () => assertSucceeds(remove(ref(db, 'lobbies/AUDIT1'))));
  await check('create read-then-set collision loses first room', 'concurrency protocol reproduction', async () => {
    const a = env.unauthenticatedContext().database();
    const b = env.unauthenticatedContext().database();
    const path = 'lobbies/RACE01';
    const reads = await Promise.all([get(ref(a, path)), get(ref(b, path))]);
    assert.ok(reads.every(x => !x.exists()));
    await set(ref(a, path), fixture('RACE01', 'first'));
    await set(ref(b, path), fixture('RACE01', 'second'));
    const final = (await get(ref(a, path))).val();
    assert.equal(final.meta.host, 'second');
    assert.equal(final.players.first, undefined);
  });
  for (const n of [2, 10, 100]) {
    await check(`${n} independent synthetic clients, 2 rooms, disjoint writes`, 'local functional test, not capacity benchmark', async () => {
      await set(ref(db, 'lobbies/ROOM01'), fixture('ROOM01'));
      await set(ref(db, 'lobbies/ROOM02'), fixture('ROOM02'));
      await Promise.all(Array.from({ length: n }, async (_, i) => {
        const c = env.unauthenticatedContext().database();
        const room = i % 2 ? 'ROOM01' : 'ROOM02';
        await set(ref(c, `lobbies/${room}/players/p${i}`), { id: `p${i}`, name: `Synthetic ${i}` });
      }));
      for (const [room, parity] of [['ROOM01', 1], ['ROOM02', 0]]) {
        const players = (await get(ref(db, `lobbies/${room}/players`))).val();
        assert.equal(Object.keys(players).length, n / 2 + 1);
        for (let i = 0; i < n; i++) assert.equal(Boolean(players[`p${i}`]), i % 2 === parity);
      }
    });
  }
} finally {
  await env.clearDatabase();
  await env.cleanup();
  await writeFile('/workspace/audit-pegel/evidence/rules-results.json', JSON.stringify(out, null, 2));
  console.log(JSON.stringify(out, null, 2));
  if (out.some(x => !x.reproduced)) process.exitCode = 1;
}
