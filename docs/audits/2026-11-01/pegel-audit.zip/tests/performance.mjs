import {chromium} from 'playwright';
import {writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const runs=[];
for(let i=0;i<3;i++){
 const ctx=await browser.newContext({viewport:{width:390,height:844},serviceWorkers:'block',reducedMotion:'reduce'});
 await ctx.route('**/*',r=>new URL(r.request().url()).hostname==='127.0.0.1'?r.continue():r.abort());
 await ctx.addInitScript(()=>{
   window.auditLCP=0;
   new PerformanceObserver(list=>{window.auditLCP=list.getEntries().at(-1)?.startTime??0}).observe({type:'largest-contentful-paint',buffered:true});
   localStorage.setItem('sdg.player',JSON.stringify({version:5,state:{onboarded:true,profile:{name:'Synthetic',color:'indigo',age:25,weightKg:75,sex:'male',stomach:'light',targetBac:.4,alcoholFree:false,designatedDriver:false},currentDrinkId:'beer-pils',log:[],carryoverLog:[],customDrinks:[],nightStartedAt:null,lastActiveAt:null,preloadAskedAt:Date.now(),waterCount:0}}));
 });
 const page=await ctx.newPage();const cdp=await ctx.newCDPSession(page);
 await cdp.send('Network.enable');await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:150,downloadThroughput:200000,uploadThroughput:93750});
 await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
 await page.goto('http://127.0.0.1:4173/Scientific-Drinking-Game/#/',{waitUntil:'networkidle'});
 runs.push(await page.evaluate(()=>({lcpMs:window.auditLCP,fcpMs:performance.getEntriesByName('first-contentful-paint')[0]?.startTime,transferBytes:performance.getEntriesByType('resource').reduce((s,r)=>s+r.transferSize,0),requests:performance.getEntriesByType('resource').length,domContentLoadedMs:performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd})));
 await ctx.close();
}
await writeFile('/workspace/audit-pegel/evidence/performance.json',JSON.stringify({environment:'Chromium headless Linux; 390x844; 4x CPU throttling; 1.6 Mbit/s down; 150ms latency; local Vite preview without CDN compression; service worker blocked; no production traffic',runs},null,2));
console.log(runs);await browser.close();
