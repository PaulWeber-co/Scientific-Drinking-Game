const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync('/workspace/Scientific-Drinking-Game/functions/index.js', 'utf8');
const sandbox = { exports: {}, require(name) {
  if (name === 'firebase-functions/scheduler') return { onSchedule: () => null };
  if (name === 'firebase-admin/app') return { initializeApp() {} };
  if (name === 'firebase-admin/database') return { getDatabase() {} };
  throw new Error(name);
}};
vm.runInNewContext(source, sandbox);
async function main() {
  const results = [];
  let live = { meta: { expiresAt: 1 } };
  const db = { ref() { return {
    orderByChild() { return this; }, endAt() { return this; },
    async get() {
      // Query captured expired version, another client deletes and recreates it
      // before the non-transactional delete is applied.
      live = { meta: { expiresAt: 999999 } };
      return { forEach(cb) { cb({ key: 'SYNTH1' }); } };
    },
    async update(patch) { if (patch.SYNTH1 === null) live = null; },
  }; }};
  await sandbox.exports.removeExpiredLobbies(db, 100);
  assert.equal(live, null);
  results.push({ name: 'cleanup deletes replacement room after query', kind: 'actual function with interleaved fake DB; not emulator', reproduced: true });
  fs.writeFileSync('/workspace/audit-pegel/evidence/local-reproductions.json', JSON.stringify(results, null, 2));
  console.log(results);
}
main().catch(e => { console.error(e); process.exitCode = 1; });
