import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
import { writeFile } from 'node:fs/promises';

const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block', reducedMotion: 'reduce' });
const outbound = [];
await context.route('**/*', route => {
  const u = new URL(route.request().url());
  if (u.hostname === '127.0.0.1' || ['data:', 'blob:'].includes(u.protocol)) return route.continue();
  outbound.push(u.hostname); return route.abort();
});
const page = await context.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
const base = 'http://127.0.0.1:4173/Scientific-Drinking-Game/';
const results = [];
await page.goto(base, { waitUntil: 'networkidle' });
results.push({ route: 'onboarding', violations: (await new AxeBuilder({page}).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze()).violations });
await page.screenshot({ path: '/workspace/audit-pegel/evidence/onboarding.png', fullPage: true });
await page.evaluate(() => {
  localStorage.setItem('sdg.player', JSON.stringify({ version: 5, state: {
    onboarded: true, profile: { name: 'Audit Test', color: 'indigo', age: 25, weightKg: 75, sex: 'male', stomach: 'light', targetBac: .4, alcoholFree: false, designatedDriver: false },
    currentDrinkId: 'beer-pils', customDrinks: [], log: [], carryoverLog: [], nightStartedAt: null, lastActiveAt: null, waterCount: 0, preloadAskedAt: Date.now(),
  }}));
  localStorage.setItem('sdg.app', JSON.stringify({ version: 6, state: { theme: 'dark', haptics: false, sound: false, calmMotion: true, waterReminder: false, disclaimerAccepted: true, recentGames: [], spicy: {}, blanks: {}, gameLength: 'mittel', taskOnSkip: 'manchmal', lastLobbyCode: null } }));
});
for (const route of ['/', '/lobby', '/pegel', '/profil', '/spiele/meme-battle']) {
  await page.goto(base + '#' + route, { waitUntil: 'networkidle' });
  await page.reload({ waitUntil: 'networkidle' });
  const axe = await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','wcag22aa']).analyze();
  results.push({ route, overflow: await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), violations: axe.violations,
    timing: await page.evaluate(() => ({ navigation: performance.getEntriesByType('navigation').map(x => ({ duration: x.duration, domContentLoaded: x.domContentLoadedEventEnd })), resources: performance.getEntriesByType('resource').reduce((sum, x) => sum + x.transferSize, 0) })) });
}
await page.goto(base+'#/pegel', {waitUntil:'networkidle'});
await page.getByRole('button', {name:'Fahrtauglichkeit'}).click();
await page.screenshot({path:'/workspace/audit-pegel/evidence/driving-calculator.png',fullPage:true});
await page.goto(base+'#/spiele/meme-battle', {waitUntil:'networkidle'});
const spicy = page.getByRole('button',{name:'Zahm',exact:true});
if (await spicy.count()) {
  await spicy.focus(); await spicy.click();
  const focus = [];
  for(let i=0;i<12;i++){ await page.keyboard.press('Tab'); focus.push(await page.evaluate(()=>({insideDialog:!!document.activeElement?.closest('[role="dialog"]'),tag:document.activeElement?.tagName,text:document.activeElement?.textContent?.slice(0,50)}))); }
  results.push({route:'spicy-dialog',focus,violations:(await new AxeBuilder({page}).analyze()).violations});
}
for(const width of [320,768,844]){
  await page.setViewportSize({width,height:width===844?390:844});
  await page.goto(base+'#/',{waitUntil:'networkidle'});
  results.push({route:'/',width,overflow:await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)});
}
await writeFile('/workspace/audit-pegel/evidence/browser-results.json',JSON.stringify({browser:await browser.version(),results,errors,blockedExternalHosts:[...new Set(outbound)]},null,2));
console.log(JSON.stringify({browser:await browser.version(),routes:results.map(x=>({route:x.route,width:x.width,overflow:x.overflow,violations:x.violations?.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})),focusEscapes:x.focus?.filter(f=>!f.insideDialog).length})),errors,blockedExternalHosts:[...new Set(outbound)]},null,2));
await browser.close();
