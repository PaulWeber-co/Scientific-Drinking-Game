import { chromium } from 'playwright';
import { writeFile } from 'node:fs/promises';
const browser = await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const c = await browser.newContext({serviceWorkers:'block'});
await c.route('**/*',r=>new URL(r.request().url()).hostname==='127.0.0.1'?r.continue():r.abort());
const url='http://127.0.0.1:4173/Scientific-Drinking-Game/#/pegel';
const a=await c.newPage();a.setDefaultTimeout(5000);await a.goto(url,{waitUntil:'networkidle'});
await a.evaluate(()=>{
 localStorage.setItem('sdg.player',JSON.stringify({version:5,state:{onboarded:true,profile:{name:'Synthetic',color:'indigo',age:25,weightKg:75,sex:'male',stomach:'light',targetBac:.4,alcoholFree:false,designatedDriver:false},currentDrinkId:'beer-pils',customDrinks:[],log:[],carryoverLog:[],nightStartedAt:null,lastActiveAt:null,waterCount:0,preloadAskedAt:Date.now()}}));
 localStorage.setItem('sdg.app',JSON.stringify({version:6,state:{disclaimerAccepted:true,theme:'dark',sound:false,haptics:false,calmMotion:true,waterReminder:false,recentGames:[],spicy:{},blanks:{},gameLength:'mittel',taskOnSkip:'manchmal',lastLobbyCode:null}}));
});
await a.goto('about:blank');await a.goto(url,{waitUntil:'networkidle'});
const b=await c.newPage();await b.goto(url,{waitUntil:'networkidle'});
async function add(page){
 await page.getByRole('button',{name:'Getränk eintragen',exact:true}).click();
 await page.getByRole('dialog').getByRole('button').filter({hasText:'Bier (Pils)'}).click();
}
const read=page=>page.evaluate(()=>JSON.parse(localStorage.getItem('sdg.player')).state.log.map(x=>x.id));
await add(a);const afterA=await read(a);
await add(b);const afterB=await read(b);
const result={firstWriteEntries:afterA.length,afterSecondTabWriteEntries:afterB.length,firstEntryRetained:afterB.includes(afterA[0]),expectedEntries:2,kind:'two real browser tabs, actual UI and Zustand persistence; no Firebase traffic'};
await writeFile('/workspace/audit-pegel/evidence/two-tabs-results.json',JSON.stringify(result,null,2));console.log(result);
await browser.close();
