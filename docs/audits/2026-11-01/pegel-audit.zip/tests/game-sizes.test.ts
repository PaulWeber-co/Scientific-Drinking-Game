import { test, expect } from '/workspace/Scientific-Drinking-Game/node_modules/vitest';
import { writeFileSync } from 'node:fs';
import { GAMES, loadGame } from '/workspace/Scientific-Drinking-Game/src/games/registry';

test('measure actual default initial states for six synthetic players', async () => {
  const players = Array.from({length:6},(_,i)=>({id:`synthetic${i}`,name:`Synthetic ${i}`,color:'indigo' as const,online:true,isHost:i===0,drinkIcon:'beer' as const}));
  const result=[];
  for(const game of GAMES){
    const def=await loadGame(game.id);
    const state=def.createState(players);
    result.push({game:game.id,utf8Bytes:new TextEncoder().encode(JSON.stringify(state)).length});
  }
  expect(result.length).toBe(20);
  writeFileSync('/workspace/audit-pegel/evidence/game-sizes.json',JSON.stringify(result,null,2));
  console.log(JSON.stringify(result));
});
